# Meetup Form

The front end for a simple app that allows users to set up events.
Created for an online class on form optimization.

Install dependencies

`npm install`

Start gulp

`gulp`

Navigate to and open

`build/index.html`