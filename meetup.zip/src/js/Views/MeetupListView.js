
class MeetupListView {
  constructor(model, root) {
    this._container = document.querySelector(root);
    this._output = this._container.querySelector(':scope ul');
    this._defaultItem = this._container.querySelector(':scope .default');
    this._model = model;
    this._active = 0;

    this._model.eventAdded.attach(function(event) {
      this.addEvent(event);
    }.bind(this));

  }

  toggleDefault() {
    if (this._active > 0) {
      if (this._defaultItem.classList.contains('hide')) return;
      this._defaultItem.classList.add('hide');
    } else {
      if (!this._defaultItem.classList.contains('hide')) return;
      this._defaultItem.classList.remove('hide');
    }
  }

  buildEventNode(event) {
    let node = document.createElement('li');
        node.classList.add('event-item');

    let date = event.eventStart.split('T')[0];
    
        node.innerHTML = `${date} - <b>${event.eventName}</b><br><i>Hosted By ${event.eventHost}</i>`;

    return node; 
  }

  addEvent(event) {
    this._active++;
    this.toggleDefault();
    this._output.appendChild(this.buildEventNode(event));
  }
}

export { MeetupListView };

// import { fakeAJAXCall } from '../Util/fakeAJAXCall';

// class MeetupListView {
//     constructor(container) {
//       this.container = document.querySelector(container);
//       this.output = this.container.querySelector(':scope ul');
//       this.default = this.container.querySelector(':scope .default');

//       this.active = 0;

//     }

//     addEvent(data) {
//       fakeAJAXCall(data).then(function(res) {
//         this.active++;
//         this.toggleDefault();
//         this.output.appendChild(this.buildEventNode(data));
//       }.bind(this));
//     }

//     toggleDefault() {
//       if (this.active > 0) {
//         if (this.default.classList.contains('hide')) return;
//         this.default.classList.add('hide');
//       } else {
//         if (!this.default.classList.contains('hide')) return;
//         this.default.classList.remove('hide');
//       }
//     }

//     buildEventNode(event) {

//       let node = document.createElement('li');
//       node.classList.add('event-item');
//       node.innerHTML = `${event.eventStart} - <b>${event.eventName}</b><br><i>Hosted By ${event.eventHost}</i>`;

//       return node;
//     }
//   }

//   export { MeetupListView };