import { Event } from "../Util/Event";
import { forEachNode } from "../Util/forEachNode";

class FormView {

  constructor(model, root) {

    this._model = model;


    this._form = document.querySelector(root);
    this._inputs = {};
    this._required = {};


    forEachNode(this._form.querySelectorAll(':scope input, :scope select, :scope textarea'), function(node) {
      let name = node.getAttribute('name');
      this._inputs[name] = node;
      if (node.hasAttribute('required')) this._required[name] = node.getAttribute('data-validation');
    }.bind(this));


    this._submitBtn = this._form.querySelector(':scope button[type=submit]');

    this.inputChanged = new Event(this);
    this.formChanged = new Event(this);
    this.formSubmitted = new Event(this);

    this._form.addEventListener('keyup', this.handleChange.bind(this));
    this._form.addEventListener('change', this.handleChange.bind(this));
    this._form.addEventListener('submit', this.handleSubmit.bind(this));

    this._model.itemValid.attach(function(key) {
      console.log(`${key} is valid!`);
      this.markValid(this._inputs[key]);
    }.bind(this));

    this._model.itemInvalid.attach(function(key) {
      console.log(`${key} is invalid!`);
      this.markInvalid(this._inputs[key]);
    }.bind(this));

    this._model.formValid.attach(function() {
      console.log('form is valid!');
      this.markFormValid();
    }.bind(this));

    this._model.formInvalid.attach(function() {
      console.log('form is invalid...');
      this.markFormInvalid(this._form);
    }.bind(this));

  }

  handleChange(evt) {

    if ((evt.target.tagName === 'INPUT') || (evt.target.tagName === 'SELECT') || (evt.target.tagName === 'TEXTAREA')) {

      let inputData = {
        name: evt.target.getAttribute('name'),
        value: evt.target.value,
        validationType: evt.target.getAttribute('data-validation')
      };

      console.log(inputData);

      this.inputChanged.notify(inputData);
    }
  }


  handleSubmit(evt) {
    evt.preventDefault();
    this.formSubmitted.notify();
  }

  markValid(node) {
    node.removeAttribute('invalid');
    node.setAttribute('valid', null);
  }

  markInvalid(node) {
    node.removeAttribute('valid');
    node.setAttribute('invalid', null);
  }

  markFormValid() {
    this._form.classList.remove('invalid');
    this._form.classList.add('valid');
    this._submitBtn.removeAttribute('disabled');
  }

  markFormInvalid() {
    this._form.classList.remove('valid');
    this._form.classList.add('invalid');
    this._submitBtn.setAttribute('disabled', null);
  }
 
  getRequired() {
    return this._required;
  }

  clear() {
    Object.keys(this._inputs).forEach(function(key) {
      
      let input = this._inputs[key];

      input.value = '';
      input.removeAttribute('invalid');
      input.removeAttribute('valid');

    }.bind(this));
  }

}

export { FormView };
