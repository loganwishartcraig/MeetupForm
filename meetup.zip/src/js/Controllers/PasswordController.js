class PasswordController {

    constructor(passwordInput, reqContainer, validationMap = {}) {

      this._passwordInput = document.querySelector(passwordInput);
      this._passwordInput.addEventListener('keyup', this.handleKeyup.bind(this));

      this._reqs = document.querySelectorAll(`${reqContainer} li[data-requirement]`);
      this._reqMap = this.buildRequirementMap(this._reqs);

      this._validationMap = validationMap;
    
    }

    buildRequirementMap(nodeList) {

      let map = {};

      for (let i = 0; i < nodeList.length; i++) {
        let key = nodeList[i].getAttribute('data-requirement');
        map[key] = nodeList[i];
      }

      return map;
    
    }

    validate(password, requirement) {

      let messageToMark = this._reqMap[requirement];

      if (messageToMark === undefined) {
        console.warn(`Password requirement message map doesn't have an <li> for ${requirement}.`);
        return;
      }

      if (!this._validationMap[requirement]) {
        console.warn(`Password validation map doesn't have a test for '${requirement}'. Assuming invalid.`);
        return this.markUnmet(messageToMark);
      }
      if (this._validationMap[requirement](password)) this.markMet(messageToMark);
      else this.markUnmet(messageToMark);

    }

    markMet(node) {
      node.classList.remove('unmet');
      if (!node.classList.contains('met'))
        node.classList.add('met');
    }

    markUnmet(node) {
      node.classList.remove('met');
      if (!node.classList.contains('unmet'))
        node.classList.add('unmet');
    }

    handleKeyup(evt) {

      let password = evt.target.value;
      
      Object.keys(this._reqMap).forEach((req) => {
        this.validate(password, req);
      });

    }

  }

  export { PasswordController };