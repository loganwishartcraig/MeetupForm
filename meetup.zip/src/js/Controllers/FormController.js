class FormController {
  constructor(model, view) {
    this._model = model;
    this._view = view;


    // For some reason, I want the 'required' flag to stay in the markup?
    this._model.setRequired(this._view.getRequired());

    this._view.inputChanged.attach(function(inputData) {
      this.setItem(inputData.name, inputData.value, inputData.validationType);
      this.checkFormValidity();
    }.bind(this));

    this._view.formSubmitted.attach(function() {
      this.checkFormValidity();
      this.submitForm();
      this.reset();
    }.bind(this))

  }

  setItem(name, value, type) {
    this._model.setItem(name, value, type);
  }

  checkFormValidity() {
    this._model.validate();
  }

  submitForm() {
    this._model.submit();
  }

  reset() {
    this._view.clear();
    this._model.clear();
    this._model.setRequired(this._view.getRequired());
  }

}

export { FormController };