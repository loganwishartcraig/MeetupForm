import { PageView } from './Views/PageView';

import { UserService } from './Services/UserService';

import { FormModel } from './Models/FormModel';
import { FormView } from './Views/FormView';
import { FormController } from './Controllers/FormController';

import { MeetupModel } from './Models/MeetupModel';
import { MeetupListView } from './Views/MeetupListView'

import { PasswordController } from './Controllers/PasswordController';

import { stdValidators, passwordValidators } from './Validators/Validators';

document.addEventListener('DOMContentLoaded', () => {

  var pageView = new PageView('body');

  var userService = new UserService(),
      userIsCached = userService.hasUser();

      pageView.toggleRegistration(userIsCached);

  if (!userIsCached) {

    var regFormModel = new FormModel(stdValidators),
        regFormView = new FormView(regFormModel, '#regForm'),
        regFormController = new FormController(regFormModel, regFormView);

        regFormModel.formSubmitted.attach((user) => {
          console.log('submitted user data!', user);
          userService.updateUserProfile(user);
          pageView.toggleRegistration(userService.hasUser());
        });

    var passwordController = new PasswordController('#password', '.pw-requirements', passwordValidators);

  }

  var meetupFormModel = new FormModel(stdValidators),
      meetupFormView = new FormView(meetupFormModel, '#meetupForm'),
      meetupFormController = new FormController(meetupFormModel, meetupFormView);

      meetupFormModel.setCustomValidator('eventGuestList', function() { return true; });
      meetupFormModel.setCustomValidator('eventStart', function() {
        return true;
      });
      meetupFormModel.setCustomValidator('eventEnd', function() {
        return true;
      });

  var meetupListModel = new MeetupModel(),
      meetupListView = new MeetupListView(meetupListModel, '.meetup-list');

      meetupFormModel.formSubmitted.attach((event) => {
        console.log('submitted event data!', event);
        meetupListModel.addEvent(event);
        meetupFormController.reset();
      });

});
