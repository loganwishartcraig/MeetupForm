function forEachNode(nodeList, cb) {
  for (let i = 0; i < nodeList.length; i++) {
    cb(nodeList[i]);
  }

}

export { forEachNode };