import { Event } from '../Util/Event';
import { fakeAJAXCall } from '../Util/fakeAJAXCall';

class FormModel {

  constructor(validationMap = {}, store = {}, required = {}) {
    this._store = store;
    this._length = 0;
    this._valid = false;
    this._required = required;

    this._validationMap = validationMap;

    this.itemSet = new Event(this);
    this.itemValid = new Event(this);
    this.itemInvalid = new Event(this);
    this.itemRemoved = new Event(this);
    this.formValid = new Event(this);
    this.formInvalid = new Event(this);
    this.formSubmitted = new Event(this);

  }

  getData() {
    return this._store;
  }

  setItem(key, value, validationType) {

    this._store[key] = value;
    this._length++;

    if (this._validationMap[validationType] !== undefined) {
      if (this._validationMap[validationType](value)) {
        this.itemValid.notify(key);
      } else {
        this.itemInvalid.notify(key);
      }
    } else {
      console.warn(`No validator for type ${validationType}. Assuming invalidity.`);
      this.itemInvalid.notify(key);
    }
    this.itemSet.notify(this._store);
  }

  removeItem(key) {

    if (this._store[key] !== undefined) {
      delete this._store[key];
      this._length--;
      this.itemRemoved.notify(this._store);
    }

  }

  validate() {

    let requiredNames = Object.keys(this._required);

    for (let i = 0; i < requiredNames.length; i++) {
     
      let name = requiredNames[i],
          test = this._validationMap[this._required[name]],
          value = this._store[name];

      if ((value === undefined) || (test === undefined) || (test(value) === false)) {
        this._valid = false;
        this.formInvalid.notify();
        return;
      }
    }

    this._valid = true;
    this.formValid.notify();

  }

  setRequired(required) {
    this._required = required;
  }

  submit() {
    if (this._valid) {
      fakeAJAXCall(this._store).then(function(msg) {
        this.formSubmitted.notify(msg);
      }.bind(this));
    }
  }

  setCustomValidator(type, validator) {
    if (this._validationMap[type] !== undefined) console.warn(`Validator already exists for type ${type}. Overwriting...`);
    this._validationMap[type] = validator;
  }

  clear() {
    console.log('clearing');
    this._store = {};
    this._required = {};
    this._length = 0;
    this._valid = false;
  }

}

export { FormModel };
