import { Event } from '../Util/Event';
import { fakeAJAXCall } from '../Util/fakeAJAXCall';

class MeetupModel {
  constructor(store = []) {
    this._store = store;

    this.eventAdded = new Event(this);
  }

  addEvent(event) {

    fakeAJAXCall(event).then(function(event) {
      this._store.push(event);
      this.eventAdded.notify(event);
    }.bind(this));

  }

}

export { MeetupModel };